/**
 * engine.js — логіка розрахунку (режими, насичення)
 */
'use strict';

const Engine = (() => {

  /**
   * Головна функція розрахунку
   */
  function compute({ mode = 'normal', T, pMPa }) {
    let result = {
      mode,
      T,
      pMPa,
      Tsat: Water.saturationTemp(pMPa),
      Psat: Water.saturationPressureMPa(T),
      phase: Water.phase(T, pMPa),
      props: {}
    };

    // ── РЕЖИМ НАСИЧЕННЯ ─────────────────────────
    if (mode === 'saturation') {
      // узгоджуємо T і p
      result.T = result.Tsat;
      result.pMPa = Water.saturationPressureMPa(result.T);
      result.phase = 'steam';
    }

    // ── ФІЗИКА ─────────────────────────────────
    let phys;
    if (result.phase === 'ice') {
      phys = Water.computeIce(result.T, result.pMPa);
    } else if (result.phase === 'steam') {
      phys = Water.computeSteam(result.T, result.pMPa);
    } else {
      phys = Water.compute(result.T, result.pMPa);
    }

    result.props = phys;

    // ── ТЕПЛОТА ПАРОУТВОРЕННЯ ───────────────────
    if (mode === 'saturation' && result.phase === 'steam') {
      const hSteam = Water.computeSteam(result.Tsat, result.pMPa).h;
      const hLiquid = Water.compute(result.Tsat, result.pMPa).h;
      result.props.r = hSteam - hLiquid; // кДж/кг
    }

    return result;
  }

  return { compute };
})();